<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require(APPPATH.'/libraries/REST_Controller.php');
use Restserver\Libraries\REST_Controller;
class Api extends REST_Controller
{

	public function __construct()
	{
		parent::__construct();	
		$this->load->library('Authorization_Token');	
		$this->load->library('form_validation');
		$this->load->model('user_m');  
	}
  	//LOGIN FOR USER
	public function login_post()
	{  
		
		$headers = $this->input->request_headers(); 
		$decodedToken = $this->authorization_token->validateToken($headers['Authorization']);

		//$resp = $this->verify_post();
		
		if($decodedToken['status']){

			$url = 'https://jsonplaceholder.typicode.com/posts';

	        $ch = curl_init($url);
	        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
	        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	        $result = curl_exec($ch);
	        curl_close($ch);

			$array  = array('status'=>'ok','data'=>$result);
			$this->response($array); 
			
		}else{
			$array  = array('status'=>'error','data'=>0);
			$this->response($array);
		}
	}
	//GETTING ALL POST VIA API CALLING
	public function record_post()
	{  

		$url = 'https://jsonplaceholder.typicode.com/posts';

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        curl_close($ch);

		$array  = array('status'=>'ok','data'=>$result);
		$this->response($array); 

        
	}
	//REGISTER AND GENERATE TOKEN
	public function register_post()
	{   
		
		$token_data['fullname'] = $this->input->post('fullname');//'jayesh'; 
		$token_data['email'] = $this->input->post('email');//'Jayesh@gmail.com';

		//echo $token_data['fullname'];
		$record['name'] = $this->input->post('fullname');
		$record['email'] = $this->input->post('email');
		$record['password'] = rand(100000,999999); 

		$response  = $this->user_m->addRecord($record);

		if($response){
			
			$tokenData = $this->authorization_token->generateToken($token_data);


			$final = array();
			$final['token'] = $tokenData;
			$final['status'] = 'User Added';
	 
			$this->response($final); 
		}else{
			$messge = array('message' => 'Something went wrong','class' => 'alert alert-danger');
			$this->session->set_flashdata('myMsj',$messge );
		}

		

	}
	//TO VERIFY TOKEN EACH TIME LOGIN AND REGISTER
	public function verify_post()
	{  
		$headers = $this->input->request_headers(); 
		$decodedToken = $this->authorization_token->validateToken($headers['Authorization']);
		//return $decodedToken;
		$this->response($decodedToken);  
	}


 
}

