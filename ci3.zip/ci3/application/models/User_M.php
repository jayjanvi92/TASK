<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_M extends CI_Model
{

	
	public function addRecord($data){  

		//print_r($data);

		$this->db->insert('users',$data); 
		return $this->db->insert_id(); 
	}

}